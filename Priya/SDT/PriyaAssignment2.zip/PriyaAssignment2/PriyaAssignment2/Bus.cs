﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriyaAssignment2
{
    class Bus:Vehicles
    {
        public Bus()
        {

        }

        public Bus(string makingyear, string modelnumber, string companyname) : base(makingyear, modelnumber, companyname)
        {

        }
        public void Cleanup()
        {

        }

        //private string cleanup;

        //public string Cleanup { get => cleanup; set => cleanup = value; }
    }
}
