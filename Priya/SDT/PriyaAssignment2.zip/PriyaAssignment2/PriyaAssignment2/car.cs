﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriyaAssignment2
{
    class Car:Vehicles
    {
        public Car()
        {

        }
        public Car(string makingyear, string modelnumber, string companyname): base(makingyear, modelnumber, companyname)
        {

        }
        public void Bodytuneup()
        {
            Console.WriteLine(" Engine bodytuneup");
        }
        //private string bodytuneup;

        //public string Bodytuneup { get => bodytuneup; set => bodytuneup = value; }
    }
}
