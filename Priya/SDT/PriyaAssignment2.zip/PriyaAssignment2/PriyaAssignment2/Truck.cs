﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriyaAssignment2
{
    class Truck:Vehicles
    {
        public Truck()
        {

        }
        public Truck(string makingyear, string modelnumber, string companyname) : base(makingyear, modelnumber, companyname)
        {

        }
        public void Installationofcover()
        {
            Console.WriteLine("Installation of cover");
        }
        //private string installationofcover;

        //public string Installationofcover { get => installationofcover; set => installationofcover = value; }
    }
}
