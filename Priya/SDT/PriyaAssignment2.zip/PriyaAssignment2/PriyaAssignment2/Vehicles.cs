﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriyaAssignment2
{
    class Vehicles
    {
        private string makingyear;
        private string modelnumber;
        private string companyname;
       
        //private string oilchange;
        //private string enginetuneup;
        //private string transmissionclean;
        public Vehicles() { }
        public Vehicles(string makingyear, string modelnumber, string companyname)
        {
            this.makingyear = makingyear;
            this.modelnumber = modelnumber;
            this.companyname = companyname;
            

        }
        public string Makingyear { get => makingyear; set => makingyear = value; }
        public string Modelnumber { get => modelnumber; set => modelnumber = value; }
        public string Companyname { get => companyname; set => companyname = value; }
        //public string Oilchange { get => oilchange; set => oilchange = value; }
        //public string Enginetuneup { get => enginetuneup; set => enginetuneup = value; }
        //public string Transmissionclean { get => transmissionclean; set => transmissionclean = value; }
       // public string Type { get => type; set => type = value; }

        public void Oilchange()
        {
            Console.WriteLine("Oil change task");
            
        }
        private void Enginetuneup()
        {
            Console.WriteLine("Engine tuneup task");

        }
        public void Detailofvehicles()
        {
            Console.WriteLine("enter manufacturer,model and year of manufacturing");
            string manufacturer = Console.ReadLine();
            string model = Console.ReadLine();
            string year = Console.ReadLine();
        }
    }
     
}
