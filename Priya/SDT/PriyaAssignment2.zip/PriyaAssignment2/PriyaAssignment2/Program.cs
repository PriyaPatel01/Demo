﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriyaAssignment2
{
    class Program
    {
        enum vehi
        {
            Car,Bus,Truck,Tractor
        }

        static void Main(string[] args)
        {
            
            Program p = new Program();
            p.Go();

        }
        public void Go()
        {
            Console.WriteLine("welcome to car mechanic shop");
            
            Console.WriteLine(" 1.Car");
            Console.WriteLine(" 2.Bus");
            Console.WriteLine(" 3.Truck");
            Console.WriteLine(" 4.Tractor");
            Console.WriteLine(" enter your choice");
            int choice;
            int.TryParse(Console.ReadLine(), out choice);
            Console.WriteLine(" 1.Oil Change ");
            Console.WriteLine(" 2. Engine Tuneup");
            Console.WriteLine(" 3.TRansmission cleanup");
            Console.WriteLine("what service you want to do?");
            char service = Console.ReadKey().KeyChar;

            string answer;
            Vehicles v = new Vehicles();
            switch (choice)
            {

                case (int)vehi.Car:
                    Car c = new Car();
                    do
                    {
                        Console.Write("Do you need body tuneup ");
                        answer = Console.ReadLine();
                    } while (answer != "Y" && answer != "N");
                    c.Bodytuneup();
                    break;

                case (int)vehi.Bus:

                    Bus b = new Bus();
                    do
                    {
                        Console.Write("Do you need body tuneup ");
                        answer = Console.ReadLine();
                    } while (answer != "Y" && answer != "N");
                    b.Cleanup();
                    break;

                case (int)vehi.Truck:

                    Truck truck = new Truck();
                    do
                    {
                        Console.Write("Do you need body tuneup ");
                        answer = Console.ReadLine();
                    } while (answer != "Y" && answer != "N");
                    truck.Installationofcover();
                    break;

                case (int)vehi.Tractor:

                    Tractor tractor = new Tractor();
                    do
                    {
                        Console.Write("Do you need body tuneup ");
                        answer = Console.ReadLine();
                    } while (answer != "Y" && answer != "N");
                    tractor.ptomanintance();
                    break;

                default:
                    throw new Exception("You shouldn't be here");
            }
            Console.ReadKey();
           

        }

    }
}
