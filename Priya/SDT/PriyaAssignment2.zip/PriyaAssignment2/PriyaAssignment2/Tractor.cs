﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriyaAssignment2
{
    class Tractor:Vehicles
    {
        public Tractor()
        {

        }
        public Tractor(string makingyear, string modelnumber, string companyname) : base(makingyear, modelnumber, companyname)
        {
            
        }
        public void ptomanintance()
        {
            Console.WriteLine("PTO maintenance ");
        }
       
       
    }
}
