﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Go();
        }

        public void Go() { 

            Console.WriteLine("Welcome to the trip");
            int numPeople = 0;
            string numString = string.Empty;
            do
            {
                Console.Write("Get Number in Group: ");
                numString = Console.ReadLine();
            } while (!int.TryParse(numString, out numPeople) || numPeople <= 0);

            Tourist[] tourArray = new Tourist[numPeople];
 
            for (int i = 0; i < numPeople; i++)
            {
                tourArray[i] = CreateTourist();
            }
            foreach(Tourist t in tourArray)
            {
                Console.WriteLine("Tourist {0} from {1}, passport {2} with {3} bags", t.Name.Split(' ')[0], t.City, t.Passport, t.NumBags);
            }
        }

        public Tourist CreateTourist()
        {
            Tourist result = new Tourist();
            string[] arrName = null;
            do
            {
                Console.Write("Get Name: ");
                result.Name = Console.ReadLine();
                arrName = result.Name.Split(' ');
            } while (result.Name == string.Empty || arrName.Length < 2);

            do
            {
                Console.Write("Get City: ");
                result.City = Console.ReadLine();
            } while (result.City == string.Empty);

            do
            {
                Console.Write("Get Passport: ");
                result.Passport = Console.ReadLine();
            } while (result.Passport == string.Empty || !result.CheckPassport());

            string strWeight = string.Empty;
            decimal weight = 0;
            do
            {
                Console.Write("Get weight: ");
                strWeight = Console.ReadLine();
            } while (strWeight == string.Empty || !decimal.TryParse(strWeight, out weight));
            result.Weight = weight;

            string strBags = string.Empty;
            int bags = 0;
            do
            {
                Console.Write("Get Number of Bags: ");
                strBags = Console.ReadLine();
            } while (strBags == string.Empty || !int.TryParse(strBags, out bags));
            result.NumBags = bags;

            return result;
        }
    }
}

