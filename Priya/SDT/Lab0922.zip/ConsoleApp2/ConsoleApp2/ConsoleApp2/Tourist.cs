﻿namespace ConsoleApp2
{
    class Tourist
    {
        private string name;
        private string city;
        private string passport;
        private int numBags;
        private decimal weight;

        public Tourist() { }
        public Tourist(string name, string city, string passport, int numBags, decimal weight)
        {
            this.name = name;
            this.city = city;
            this.passport = passport;
            this.numBags = numBags;
            this.weight = weight;
        }

        public string Name { get { return name; } set { name = value; } }
        public string City { get { return city; } set { city = value; } }
        public string Passport { get { return ConcealedPassport(); } set { passport = value; } }
        public int NumBags { get { return numBags; } set { numBags = value; } }
        public decimal Weight { get { return weight; } set { weight = value; } }

        public bool CheckPassport()
        {
            bool result = false;
            if (passport != null && passport != string.Empty )
            {
                char[] passArray = passport.ToCharArray();
                if (char.IsLetter(passArray[0]) && char.IsLetter(passArray[1]))
                {
                    for (int i = 2; i < passArray.Length; i++)
                    {
                        if (char.IsDigit(passArray[i]))
                        {
                            result = true;
                        } else
                        {
                            result = false;
                            break;
                        }
                    }
                }
            }
            return result;
        }

        private string ConcealedPassport()
        {
            char[] passArray = passport.ToCharArray();
            for (int i = 2; i < 5; i++)
            {
                passArray[i] = 'X';
            }
            return new string(passArray);
        }
    }
}
